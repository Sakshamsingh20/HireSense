# HireSense AI — Prototype (Flask + TF-IDF matching)

## Overview
This is a lightweight prototype of the HireSense AI platform. It allows you to:
- Upload candidate resumes (PDF or TXT)
- Add job descriptions
- Run TF-IDF based matching between job description and candidate resumes
- View top matches in a simple dashboard

## Setup (local)
1. Create a virtual environment (recommended) and activate it.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the app:
   ```bash
   python app.py
   ```
4. Open `http://localhost:8080` in your browser.

## Notes
- PDF text extraction uses `PyPDF2`. If a PDF does not yield text, try uploading a `.txt` resume as fallback.
- This prototype uses `database.json` as a simple local store (no DB required).
- For production, replace local JSON with MongoDB/Postgres and improve PDF parsing (using spaCy + PyMuPDF).

## Endpoints (quick)
- `/` — Web dashboard
- `/upload_resume` — POST (form) upload resume
- `/add_job` — POST (form) add job
- `/match/<job_id>` — View matches for job
- `/api/match/<job_id>` — JSON API for matches
